<?php
/**
 * Created by PhpStorm.
 * User: seb
 * Date: 02/07/2018
 * Time: 10:13
 */

class HupiAjaxModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    /*
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();

        $order = new Order((int)Tools::getValue('orderid'));
        if (!Validate::isLoadedObject($order) || $order->id_customer != (int)Tools::getValue('customer')) {
            die;
        }
        Db::getInstance()->execute(
            'UPDATE `'._DB_PREFIX_.'hupi` SET sent = 1, date_add = NOW() WHERE id_order = '.(int)Tools::getValue('orderid').' LIMIT 1'
        );
        die;
    }
}