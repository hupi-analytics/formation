<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{hupi}prestashop>hupi_ad3232115ebebd7b71562132bb8ab4ca'] = 'Hupi';
$_MODULE['<{hupi}prestashop>hupi_dd0467688592d264b6e8d6379ec52272'] = 'Permet d\'envoyer des données analytiques aux serveurs Hupi et d\'afficher en retour des recommandations de produits';
$_MODULE['<{hupi}prestashop>hupi_7d9977ede66b93de9be6b2bcc581420a'] = 'Êtes-vous sûr de bien vouloir désinstaller ce module ?';
$_MODULE['<{hupi}prestashop>hupi_228264cd2bcc9d462f020dae71003d8b'] = 'ID Compte chez Hupi';
$_MODULE['<{hupi}prestashop>hupi_3cefa460214da04b44943d4874e0f8b0'] = 'Cette information est fournie par Hupi';
$_MODULE['<{hupi}prestashop>hupi_83cf4af58b797e9de698977d040aa6be'] = 'ID Site chez Hupi';
$_MODULE['<{hupi}prestashop>hupi_bcd08e73ca9d8bfed2cccd50dd6d8328'] = 'Activer la fonctionnalité \"User-ID\" ';
$_MODULE['<{hupi}prestashop>configure_3b1fce8ffc49e3a4f2df628c8c5d2450'] = 'Configuration des recommandations';
$_MODULE['<{hupi}prestashop>configure_733d627f03d038791dba252b1310e78e'] = 'Activer les recommandations ?';
$_MODULE['<{hupi}prestashop>configure_1a1fb71970f9a9156e7e047d24570fe7'] = 'Token de l\'API';
$_MODULE['<{hupi}prestashop>configure_b9975795ebc3d076cbcfe791e1796f4b'] = 'Affichage des recommandations sur la page produit ?';
$_MODULE['<{hupi}prestashop>configure_83f2e8f6eeac7b74297a4c9d4450f9e3'] = 'Nom du endpoint :';
$_MODULE['<{hupi}prestashop>configure_0e48eaa0439381cba0dc1b0d1f70d844'] = 'Nombre de produits :';
$_MODULE['<{hupi}prestashop>configure_187206585298c963c3fe59a467c9eb9a'] = 'Affichage des recommandations sur la page panier ?';
$_MODULE['<{hupi}prestashop>configure_9327cf4b295929fb1a410d94875a23aa'] = 'Affichage des recommandations sur la page catégories ?';
$_MODULE['<{hupi}prestashop>configure_c004fedae65d695d81c4cd3155c0e720'] = 'Affichage des recommandations sur la page d\'accueil ?';
$_MODULE['<{hupi}prestashop>category_0f169d3dc0db47a4074489a89cb034b5'] = 'Nous vous recommandons';
$_MODULE['<{hupi}prestashop>recommendations_0f169d3dc0db47a4074489a89cb034b5'] = 'Nous vous recommandons';
$_MODULE['<{hupi}prestashop>shopping-cart_70ed7073aa7a3316183b135ebbc23d02'] = 'Complétez votre panier avec :';
